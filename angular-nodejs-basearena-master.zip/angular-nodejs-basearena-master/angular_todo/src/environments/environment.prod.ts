export const environment = {
  production: true,
  hostname: 'localhost:1337',
};
